# Configuration for acceptance tests (rake test:acceptance)

require_relative '../test_helper'
require 'capybara/rspec'

Capybara.app = App